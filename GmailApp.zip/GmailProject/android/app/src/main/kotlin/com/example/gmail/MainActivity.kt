package com.example.gmail

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
